# ============================================================
# GAMM pipeline (Psychophysiology-ready) — FINAL (Run all in one)
#  - M1/M2: TIME-BY-CONDITION s(Time_s, by=CondName)
#  - S1–S4: TIME-BY-CONDITION s(Time_s, by=CondName)
#  - M3: VARYING-COEFFICIENT (time coefficient varies with Lv/DER)
#        s(Time_s, by=Lv_phys_z) + s(Time_s, by=DER_phys_z)
#
# OUTPUT (for Recommended A = equal-weight mean across 4 conditions):
#  - Fig1: condition-wise predicted PLR (pointwise CI)
#  - Fig2: Dunn axes (LowTh, Active) — equal-weight mean (pointwise CI + diff simul CI) + CSV
#  - Fig3: AASP quadrants diff (High-Low) — equal-weight mean (simul CI) + CSV
#  - Fig4: AASP quadrants predicted (High/Low) — equal-weight mean (pointwise CI) + CSV
#
# MODELS:
#  - M1/S1/S2/S3/S4: K_MAIN=60, K_COND=20, TI=60, FS=10
#  - M2/M3:          K_MAIN=100, K_COND=40, TI=60, FS=20
#  - M3: K_TIME_PHYS=100
#
# + Saves model objects as .rds
# + Uses AR(1) with rho estimated from M0_core (no AR1) in the M1-setting dataset
# + PREDICTIONS: population-level only (exclude random effects)
# ============================================================

# ---------------------------
# 0) User settings (EDIT)
# ---------------------------
PATH_LONG_3S <- "dataset_gamm_long_3s.csv"
PATH_METRICS <- "stimulus_metrics_condition_mean_sd.csv"  # for M3 (optional)

RUN_TAG <- format(Sys.time(), "%Y%m%d_%H%M%S")
OUT_DIR <- paste0("gamm_outputs_TBC_VCphys_EQCOND_0to3s_", RUN_TAG)

KEEP_CONDS <- c("White","Red","Green","Blue")
COND_WTS   <- setNames(rep(1/length(KEEP_CONDS), length(KEEP_CONDS)), KEEP_CONDS)  # equal-weight

BIN_STEP_S      <- 0.01
TIME_MIN_S      <- 0
TIME_MAX_S      <- 3
WHITE_MIN_VALID <- 6

# CI settings
NSIM  <- 4000
ALPHA <- 0.05

# ---------------------------
# 1) Packages
# ---------------------------
pkgs <- c("dplyr","readr","janitor","mgcv","itsadug","MASS","ggplot2","grid")
to_install <- pkgs[!sapply(pkgs, requireNamespace, quietly=TRUE)]
if (length(to_install) > 0) install.packages(to_install)
invisible(lapply(pkgs, library, character.only=TRUE))

# ---------------------------
# 2) Output folders
# ---------------------------
dir.create(OUT_DIR, showWarnings=FALSE, recursive=TRUE)

DIR_M1 <- file.path(OUT_DIR, "M1_core_primary_TBC")
DIR_M2 <- file.path(OUT_DIR, "M2_core_psychcov_TBC")
DIR_M3 <- file.path(OUT_DIR, "M3_core_physical_VC")
DIR_S  <- file.path(OUT_DIR, "Supplement_quadrants_TBC")
DIR_F  <- file.path(OUT_DIR, "Figures_EQCOND")
DIR_SM <- file.path(OUT_DIR, "SM_diagnostics")

dirs <- c(DIR_M1, DIR_M2, DIR_M3, DIR_S, DIR_F, DIR_SM)
invisible(lapply(dirs, dir.create, showWarnings=FALSE, recursive=TRUE))

# ---------------------------
# 3) Load long data (3s) + restrict to 4 conditions
# ---------------------------
dat0 <- readr::read_csv(PATH_LONG_3S, show_col_types = FALSE) %>%
  dplyr::filter(CondName %in% KEEP_CONDS) %>%
  dplyr::mutate(CondName = factor(CondName, levels=KEEP_CONDS))

# ---------------------------
# 4) Included_PRIMARY (White >= 6 valid trials @0-3s)
# ---------------------------
tri <- dat0 %>%
  dplyr::distinct(Subject_ID, Trial_ID, CondName, TrialRejected_3s)

incl_ids <- tri %>%
  dplyr::filter(CondName == "White") %>%
  dplyr::group_by(Subject_ID) %>%
  dplyr::summarise(valid_white = sum(!TrialRejected_3s), .groups="drop") %>%
  dplyr::filter(valid_white >= WHITE_MIN_VALID) %>%
  dplyr::pull(Subject_ID)

dat <- dat0 %>%
  dplyr::filter(
    Subject_ID %in% incl_ids,
    Time_s >= TIME_MIN_S, Time_s <= TIME_MAX_S,
    SampleValid_3s == TRUE,
    !is.na(Pupil_Combined)
  )

# ---------------------------
# 5) Subject-level z + Dunn 2 axes
# ---------------------------
z <- function(x) as.numeric(scale(x))

req_cols <- c("Subject_ID","Sex_bin","age","CondName","Trial_ID","Time_s","Pupil_Combined",
              "TrialRejected_3s","SampleValid_3s",
              "AASP R","AASP K","AASP S","AASP A","AQ","ASRS Total","BDI-Ⅱ","A-State","A-Trait")
missing_cols <- setdiff(req_cols, names(dat))
if (length(missing_cols) > 0) stop("Missing columns: ", paste(missing_cols, collapse=", "))

subj <- dat %>%
  dplyr::distinct(Subject_ID, Sex_bin, age,
                  `AASP R`, `AASP K`, `AASP S`, `AASP A`,
                  AQ, `ASRS Total`, `BDI-Ⅱ`, `A-State`, `A-Trait`) %>%
  dplyr::mutate(
    # quadrant z
    LReg_z   = z(`AASP R`),
    SSeek_z  = z(`AASP K`),
    SSens_z  = z(`AASP S`),
    SAvoid_z = z(`AASP A`),

    # Dunn axes (from quadrant z)
    LowTh    = (SSens_z + SAvoid_z - LReg_z - SSeek_z)/2,
    Active   = (SSeek_z + SAvoid_z - LReg_z - SSens_z)/2,
    LowTh_z   = z(LowTh),
    Active_z  = z(Active),

    # covariates
    age_z     = z(age),
    AQ_z      = z(AQ),
    ASRS_z    = z(`ASRS Total`),
    BDI_z     = z(`BDI-Ⅱ`),
    STAI_S_z  = z(`A-State`),
    STAI_T_z  = z(`A-Trait`)
  )

dat <- dat %>%
  dplyr::select(-Sex_bin, -age, -`AASP R`, -`AASP K`, -`AASP S`, -`AASP A`,
                -AQ, -`ASRS Total`, -`BDI-Ⅱ`, -`A-State`, -`A-Trait`) %>%
  dplyr::left_join(subj, by="Subject_ID")

# ---------------------------
# 6) AR.start creation (trial boundary + time gaps)
# ---------------------------
dat <- dat %>%
  dplyr::arrange(Subject_ID, Trial_ID, Time_s) %>%
  dplyr::group_by(Subject_ID, Trial_ID) %>%
  dplyr::mutate(
    dt = Time_s - dplyr::lag(Time_s),
    AR.start = dplyr::row_number() == 1 | is.na(dt) | dt > (BIN_STEP_S * 1.1)
  ) %>%
  dplyr::ungroup() %>%
  dplyr::mutate(
    Subject_ID = factor(Subject_ID),
    CondName   = factor(CondName, levels=KEEP_CONDS)
  )

tgrid <- seq(TIME_MIN_S, TIME_MAX_S, by=BIN_STEP_S)

# Exclude random effects for population-level predictions
exclude_terms <- c("s(Subject_ID)", "s(Time_s,Subject_ID)")

# ============================================================
# 7) Helper: base newdata template
# ============================================================
make_nd_template <- function(dat_ref, tgrid, cond) {
  data.frame(
    Time_s   = tgrid,
    CondName = factor(cond, levels=levels(dat_ref$CondName)),
    LowTh_z  = 0,
    Active_z = 0,
    age_z    = 0,
    Sex_bin  = 0,
    AQ_z     = 0,
    ASRS_z   = 0,
    BDI_z    = 0,
    STAI_S_z = 0,
    STAI_T_z = 0,
    LReg_z   = 0,
    SSeek_z  = 0,
    SSens_z  = 0,
    SAvoid_z = 0,
    Lv_phys_z  = 0,
    DER_phys_z = 0,
    Subject_ID = dat_ref$Subject_ID[1]
  )
}

# ============================================================
# 8) Helper: equal-weight mean prediction via averaged lpmatrix
# ============================================================
# Returns averaged linear predictor and SE (pointwise) for given newdata generator
# - We average X matrices across conditions: Xbar = sum_w X_cond
# - Then: fit = Xbar %*% beta; se = sqrt(diag(Xbar V Xbar^T))
predict_eqcond_pointwise <- function(model, nd_list, wts, exclude_terms) {
  beta <- coef(model)
  V    <- vcov(model)

  # Build Xbar
  Xbar <- NULL
  for (cond in names(nd_list)) {
    Xc <- predict(model, newdata=nd_list[[cond]], type="lpmatrix", exclude=exclude_terms)
    if (is.null(Xbar)) Xbar <- 0 * Xc
    Xbar <- Xbar + wts[[cond]] * Xc
  }

  fit <- as.numeric(Xbar %*% beta)
  se  <- sqrt(rowSums((Xbar %*% V) * Xbar))
  list(fit=fit, se=se, Xbar=Xbar)
}

# ============================================================
# 9) Helper: equal-weight mean for High/Low + simultaneous CI for Diff
# ============================================================
eqcond_hi_lo_with_simul_diff <- function(
    model, trait_col,
    nd_base_per_cond, wts, exclude_terms,
    hi_val=1, lo_val=-1,
    nsim=NSIM, alpha=ALPHA
) {

  # Build per-condition nd for hi/lo
  nd_hi_list <- nd_lo_list <- list()
  for (cond in names(nd_base_per_cond)) {
    nd_hi <- nd_base_per_cond[[cond]]
    nd_lo <- nd_base_per_cond[[cond]]
    nd_hi[[trait_col]] <- hi_val
    nd_lo[[trait_col]] <- lo_val
    nd_hi_list[[cond]] <- nd_hi
    nd_lo_list[[cond]] <- nd_lo
  }

  beta <- coef(model)
  V    <- vcov(model)

  # Xbar for hi and lo
  Xbar_hi <- NULL
  Xbar_lo <- NULL
  for (cond in names(nd_hi_list)) {
    Xh <- predict(model, newdata=nd_hi_list[[cond]], type="lpmatrix", exclude=exclude_terms)
    Xl <- predict(model, newdata=nd_lo_list[[cond]], type="lpmatrix", exclude=exclude_terms)
    if (is.null(Xbar_hi)) Xbar_hi <- 0 * Xh
    if (is.null(Xbar_lo)) Xbar_lo <- 0 * Xl
    Xbar_hi <- Xbar_hi + wts[[cond]] * Xh
    Xbar_lo <- Xbar_lo + wts[[cond]] * Xl
  }

  fit_hi <- as.numeric(Xbar_hi %*% beta)
  fit_lo <- as.numeric(Xbar_lo %*% beta)
  diff   <- fit_hi - fit_lo

  # pointwise SEs
  se_hi   <- sqrt(rowSums((Xbar_hi %*% V) * Xbar_hi))
  se_lo   <- sqrt(rowSums((Xbar_lo %*% V) * Xbar_lo))
  Xdiff   <- Xbar_hi - Xbar_lo
  se_diff <- sqrt(rowSums((Xdiff %*% V) * Xdiff))

  zcrit <- qnorm(1 - alpha/2)
  pw_hi_lo <- fit_hi - zcrit * se_hi
  pw_hi_hi <- fit_hi + zcrit * se_hi
  pw_lo_lo <- fit_lo - zcrit * se_lo
  pw_lo_hi <- fit_lo + zcrit * se_lo

  pw_diff_lo <- diff - zcrit * se_diff
  pw_diff_hi <- diff + zcrit * se_diff

  # simultaneous CI for diff via coefficient simulation
  bsim <- MASS::mvrnorm(nsim, mu=beta, Sigma=V)
  sim  <- Xdiff %*% t(bsim)                # [time x nsim]
  tmax <- apply(abs((sim - diff) / se_diff), 2, max, na.rm=TRUE)
  crit <- as.numeric(quantile(tmax, 1 - alpha, na.rm=TRUE))
  sim_diff_lo <- diff - crit * se_diff
  sim_diff_hi <- diff + crit * se_diff

  list(
    fit_hi=fit_hi, fit_lo=fit_lo,
    pw_hi_lo=pw_hi_lo, pw_hi_hi=pw_hi_hi,
    pw_lo_lo=pw_lo_lo, pw_lo_hi=pw_lo_hi,
    diff=diff,
    se_diff=se_diff,
    pw_diff_lo=pw_diff_lo, pw_diff_hi=pw_diff_hi,
    sim_diff_lo=sim_diff_lo, sim_diff_hi=sim_diff_hi
  )
}

# ============================================================
# 10) Helper: save plots + CSVs (EQCOND)
# ============================================================
make_ros_segments <- function(time, lo, hi) {
  sig <- (lo > 0) | (hi < 0)
  if (!any(sig)) return(data.frame(xmin=numeric(0), xmax=numeric(0)))
  r <- rle(sig)
  ends <- cumsum(r$lengths)
  starts <- ends - r$lengths + 1
  data.frame(val=r$values, start=starts, end=ends) %>%
    dplyr::filter(val == TRUE) %>%
    dplyr::transmute(xmin=time[start], xmax=time[end])
}

plot_pred_and_diff_eqcond <- function(time, res, title, out_png) {

  df_pred <- data.frame(
    Time_s=time,
    PPC_hi=res$fit_hi, PPC_lo=res$fit_lo,
    PPC_hi_lo=res$pw_hi_lo, PPC_hi_hi=res$pw_hi_hi,
    PPC_lo_lo=res$pw_lo_lo, PPC_lo_hi=res$pw_lo_hi
  )

  df_diff <- data.frame(Time_s=time, Diff=res$diff, lo=res$sim_diff_lo, hi=res$sim_diff_hi)
  segs <- make_ros_segments(time, res$sim_diff_lo, res$sim_diff_hi)

  p1 <- ggplot(df_pred, aes(x=Time_s)) +
    geom_ribbon(aes(ymin=PPC_hi_lo, ymax=PPC_hi_hi), alpha=0.20) +
    geom_line(aes(y=PPC_hi)) +
    geom_ribbon(aes(ymin=PPC_lo_lo, ymax=PPC_lo_hi), alpha=0.20) +
    geom_line(aes(y=PPC_lo), linetype="dashed") +
    labs(title=title,
         x="Time (s)",
         y="Predicted PPC (equal-weight mean)\nPointwise 95% CI") +
    theme_classic()

  p2 <- ggplot(df_diff, aes(x=Time_s, y=Diff)) +
    geom_hline(yintercept=0, linetype="dotted") +
    geom_ribbon(aes(ymin=lo, ymax=hi), alpha=0.20) +
    geom_line() +
    labs(x="Time (s)",
         y="Difference (High − Low)\nSimultaneous 95% CI (FWER-controlled)") +
    theme_classic()

  if (nrow(segs) > 0) {
    ybar <- min(df_diff$lo, na.rm=TRUE)
    p2 <- p2 + geom_segment(data=segs,
                            aes(x=xmin, xend=xmax, y=ybar, yend=ybar),
                            linewidth=2)
  }

  g1 <- ggplotGrob(p1)
  g2 <- ggplotGrob(p2)

  png(out_png, width=1100, height=1200)
  grid::grid.newpage()
  lay <- grid::grid.layout(nrow=2, ncol=1, heights=grid::unit(c(0.55, 0.45), "npc"))
  v <- grid::viewport(layout=lay)
  grid::pushViewport(v)
  grid::pushViewport(grid::viewport(layout.pos.row=1, layout.pos.col=1))
  grid::grid.draw(g1)
  grid::popViewport()
  grid::pushViewport(grid::viewport(layout.pos.row=2, layout.pos.col=1))
  grid::grid.draw(g2)
  grid::popViewport(2)
  dev.off()
}

# Condition-wise waveform (Fig1): pointwise CI per condition (population-level)
pred_ci_by_condition <- function(model, dat_ref, tgrid, conds,
                                 exclude_terms, alpha, out_csv) {

  zcrit <- qnorm(1 - alpha/2)
  beta <- coef(model)
  V    <- vcov(model)

  out_list <- list()
  for (cond in conds) {
    nd <- make_nd_template(dat_ref, tgrid, cond=cond)
    X  <- predict(model, newdata=nd, type="lpmatrix", exclude=exclude_terms)
    fit <- as.numeric(X %*% beta)
    se  <- sqrt(rowSums((X %*% V) * X))
    out_list[[cond]] <- data.frame(
      Time_s=tgrid, CondName=cond,
      PPC_pred=fit,
      PPC_lo=fit - zcrit*se,
      PPC_hi=fit + zcrit*se
    )
  }
  out_df <- dplyr::bind_rows(out_list)
  readr::write_csv(out_df, out_csv)
  invisible(out_df)
}

# AASP quadrant predicted curves (Fig4): EQCOND pointwise CI (no diff)
export_quadrant_pred_eqcond <- function(model, trait_col, quadrant_label,
                                       dat_ref, tgrid, conds, wts,
                                       exclude_terms, alpha) {

  zcrit <- qnorm(1 - alpha/2)

  # base per cond
  nd_base <- lapply(conds, function(cn) make_nd_template(dat_ref, tgrid, cn))
  names(nd_base) <- conds

  # hi and lo
  nd_hi <- lapply(nd_base, function(nd){ nd[[trait_col]] <- 1; nd })
  nd_lo <- lapply(nd_base, function(nd){ nd[[trait_col]] <- -1; nd })

  # EQCOND pointwise for hi
  pr_hi <- predict_eqcond_pointwise(model, nd_hi, wts, exclude_terms)
  pr_lo <- predict_eqcond_pointwise(model, nd_lo, wts, exclude_terms)

  data.frame(
    Time_s=tgrid,
    Quadrant=quadrant_label,
    PPC_hi=pr_hi$fit,
    PPC_hi_lo=pr_hi$fit - zcrit*pr_hi$se,
    PPC_hi_hi=pr_hi$fit + zcrit*pr_hi$se,
    PPC_lo=pr_lo$fit,
    PPC_lo_lo=pr_lo$fit - zcrit*pr_lo$se,
    PPC_lo_hi=pr_lo$fit + zcrit*pr_lo$se,
    CI="Pointwise 95% (EQCOND)"
  )
}

# ============================================================
# 11) Model fitting functions (with per-model k)
# ============================================================
fit_M0_core_noAR1 <- function(dat, K_TIME_MAIN, K_TIME_COND, K_TI_TIME, K_TI_TRAIT, K_FS_SUBJ) {
  mgcv::bam(
    Pupil_Combined ~
      CondName +
      s(Time_s, k=K_TIME_MAIN, bs="cr") +
      s(Time_s, by=CondName, k=K_TIME_COND, bs="cr") +
      LowTh_z + Active_z +
      ti(Time_s, LowTh_z,  bs=c("cr","tp"), k=c(K_TI_TIME, K_TI_TRAIT)) +
      ti(Time_s, Active_z, bs=c("cr","tp"), k=c(K_TI_TIME, K_TI_TRAIT)) +
      age_z + Sex_bin +
      s(Subject_ID, bs="re") +
      s(Time_s, Subject_ID, bs="fs", k=K_FS_SUBJ),
    data=dat,
    method="fREML",
    discrete=TRUE
  )
}

fit_M1_core_AR1 <- function(m0_core, rho, dat) {
  update(m0_core, rho=rho, AR.start=dat$AR.start)
}

fit_M2_core <- function(m1_core) {
  update(m1_core, . ~ . + AQ_z + ASRS_z + BDI_z + STAI_S_z + STAI_T_z)
}

fit_M3_core <- function(dat_m3, rho,
                        K_TIME_MAIN, K_TIME_PHYS, K_TI_TIME, K_TI_TRAIT, K_FS_SUBJ) {
  mgcv::bam(
    Pupil_Combined ~
      s(Time_s, k=K_TIME_MAIN, bs="cr") +
      Lv_phys_z + DER_phys_z +
      s(Time_s, by=Lv_phys_z,  k=K_TIME_PHYS, bs="cr") +
      s(Time_s, by=DER_phys_z, k=K_TIME_PHYS, bs="cr") +
      LowTh_z + Active_z +
      ti(Time_s, LowTh_z,  bs=c("cr","tp"), k=c(K_TI_TIME, K_TI_TRAIT)) +
      ti(Time_s, Active_z, bs=c("cr","tp"), k=c(K_TI_TIME, K_TI_TRAIT)) +
      age_z + Sex_bin +
      s(Subject_ID, bs="re") +
      s(Time_s, Subject_ID, bs="fs", k=K_FS_SUBJ),
    data=dat_m3,
    method="fREML",
    discrete=TRUE,
    rho=rho,
    AR.start=dat_m3$AR.start
  )
}

fit_S_model <- function(dat, rho, trait_z_name,
                        K_TIME_MAIN, K_TIME_COND, K_TI_TIME, K_TI_TRAIT, K_FS_SUBJ) {
  f_txt <- paste0(
    "Pupil_Combined ~ CondName + ",
    "s(Time_s, k=", K_TIME_MAIN, ", bs='cr') + ",
    "s(Time_s, by=CondName, k=", K_TIME_COND, ", bs='cr') + ",
    "age_z + Sex_bin + AQ_z + ASRS_z + BDI_z + STAI_S_z + STAI_T_z + ",
    "s(Subject_ID, bs='re') + s(Time_s, Subject_ID, bs='fs', k=", K_FS_SUBJ, ") + ",
    trait_z_name, " + ti(Time_s, ", trait_z_name, ", bs=c('cr','tp'), k=c(", K_TI_TIME, ",", K_TI_TRAIT, "))"
  )
  mgcv::bam(
    as.formula(f_txt),
    data=dat,
    method="fREML",
    discrete=TRUE,
    rho=rho,
    AR.start=dat$AR.start
  )
}

# ============================================================
# 12) FIT MODELS (one run)
# ============================================================

# ---- Settings
# M1/S: 60/20/TI60/FS10
K_M1_MAIN <- 60
K_M1_COND <- 20
K_M1_TI_T <- 60
K_M1_TI_Z <- 5
K_M1_FS   <- 10

# M2/M3: 100/40/TI60/FS20 ; M3 PHYS=100
K_M2_MAIN <- 100
K_M2_COND <- 40
K_M2_TI_T <- 60
K_M2_TI_Z <- 5
K_M2_FS   <- 20

K_M3_PHYS <- 100

# ---- M0/M1 (use M1-setting to estimate rho)
message("Fitting M0 (no AR1) with M1 settings ...")
m0_core <- fit_M0_core_noAR1(dat, K_M1_MAIN, K_M1_COND, K_M1_TI_T, K_M1_TI_Z, K_M1_FS)

# ★ここに追加：M0を保存
saveRDS(m0_core, file=file.path(DIR_M1, "model_M0_core_noAR1.rds"))

rho <- itsadug::start_value_rho(m0_core)
writeLines(sprintf("rho_estimated=%.6f", rho), con=file.path(DIR_SM, "rho_estimated.txt"))

png(file.path(DIR_SM, "acf_resid_M0_core_noAR1.png"), width=1000, height=700)
itsadug::acf_resid(m0_core); dev.off()

message("Fitting M1 (AR1) ...")
m1_core <- fit_M1_core_AR1(m0_core, rho, dat)

png(file.path(DIR_SM, "acf_resid_M1_core_AR1.png"), width=1000, height=700)
itsadug::acf_resid(m1_core); dev.off()

# Save M1 text + model
capture.output(summary(m1_core), file=file.path(DIR_M1, "summary_M1_core_TBC.txt"))
capture.output(gam.check(m1_core), file=file.path(DIR_M1, "gamcheck_M1_core_TBC.txt"))
capture.output(mgcv::concurvity(m1_core, full=TRUE), file=file.path(DIR_M1, "concurvity_M1_core_TBC_full.txt"))
saveRDS(m1_core, file=file.path(DIR_M1, "model_M1_core_TBC.rds"))

# ---- M2 (refit with M2 settings in one go; do NOT update from M1 because k differs)
message("Fitting M2 with its own k settings (100/40/TI60/FS20) ...")
m0_m2 <- fit_M0_core_noAR1(dat, K_M2_MAIN, K_M2_COND, K_M2_TI_T, K_M2_TI_Z, K_M2_FS)
m2_core <- update(m0_m2, rho=rho, AR.start=dat$AR.start)
m2_core <- update(m2_core, . ~ . + AQ_z + ASRS_z + BDI_z + STAI_S_z + STAI_T_z)

png(file.path(DIR_SM, "acf_resid_M2_core_AR1.png"), width=1000, height=700)
itsadug::acf_resid(m2_core); dev.off()

capture.output(summary(m2_core), file=file.path(DIR_M2, "summary_M2_core_TBC.txt"))
capture.output(gam.check(m2_core), file=file.path(DIR_M2, "gamcheck_M2_core_TBC.txt"))
capture.output(mgcv::concurvity(m2_core, full=TRUE), file=file.path(DIR_M2, "concurvity_M2_core_TBC_full.txt"))
saveRDS(m2_core, file=file.path(DIR_M2, "model_M2_core_TBC.rds"))

# ---- M3 (optional; needs metrics)
m3_core <- NULL
dat_m3  <- NULL
if (file.exists(PATH_METRICS)) {
  message("Preparing metrics join for M3 ...")
  metrics <- readr::read_csv(PATH_METRICS, show_col_types = FALSE) %>%
    janitor::clean_names() %>%
    dplyr::rename(CondName = condition) %>%
    dplyr::filter(CondName %in% KEEP_CONDS) %>%
    dplyr::mutate(CondName = factor(CondName, levels=KEEP_CONDS))

  dat_m3 <- dat %>% dplyr::left_join(metrics, by="CondName")

  if (any(is.na(dat_m3$lv_cd_m2_mean))) stop("Join failed: lv_cd_m2_mean has NA. Check CondName labels.")
  if (any(is.na(dat_m3$melanopic_der_mean))) stop("Join failed: melanopic_der_mean has NA. Check metrics CSV.")

  dat_m3 <- dat_m3 %>%
    dplyr::mutate(
      Lv_phys_z  = z(lv_cd_m2_mean),
      DER_phys_z = z(melanopic_der_mean)
    )

  message("Fitting M3 (VC phys) with M2/M3 settings + K_TIME_PHYS=100 ...")
  m3_core <- fit_M3_core(dat_m3, rho,
                         K_TIME_MAIN=K_M2_MAIN,
                         K_TIME_PHYS=K_M3_PHYS,
                         K_TI_TIME=K_M2_TI_T,
                         K_TI_TRAIT=K_M2_TI_Z,
                         K_FS_SUBJ=K_M2_FS)

  png(file.path(DIR_SM, "acf_resid_M3_core_AR1.png"), width=1000, height=700)
  itsadug::acf_resid(m3_core); dev.off()

  capture.output(summary(m3_core), file=file.path(DIR_M3, "summary_M3_core_VCphys.txt"))
  capture.output(gam.check(m3_core), file=file.path(DIR_M3, "gamcheck_M3_core_VCphys.txt"))
  capture.output(mgcv::concurvity(m3_core, full=TRUE), file=file.path(DIR_M3, "concurvity_M3_core_VCphys_full.txt"))
  saveRDS(m3_core, file=file.path(DIR_M3, "model_M3_core_VCphys.rds"))
} else {
  message("PATH_METRICS not found; skipping M3.")
}

# ---- S1–S4 (all with M1 settings; S2 also M1 settings per your decision)
message("Fitting S models (S1–S4) with M1 settings ...")
S_LReg   <- fit_S_model(dat, rho, "LReg_z",   K_M1_MAIN, K_M1_COND, K_M1_TI_T, K_M1_TI_Z, K_M1_FS)
S_SSeek  <- fit_S_model(dat, rho, "SSeek_z",  K_M1_MAIN, K_M1_COND, K_M1_TI_T, K_M1_TI_Z, K_M1_FS)
S_SSens  <- fit_S_model(dat, rho, "SSens_z",  K_M1_MAIN, K_M1_COND, K_M1_TI_T, K_M1_TI_Z, K_M1_FS)
S_SAvoid <- fit_S_model(dat, rho, "SAvoid_z", K_M1_MAIN, K_M1_COND, K_M1_TI_T, K_M1_TI_Z, K_M1_FS)

png(file.path(DIR_SM, "acf_resid_S1_LReg_AR1.png"), width=1000, height=700)
itsadug::acf_resid(S_LReg); dev.off()
png(file.path(DIR_SM, "acf_resid_S2_SSeek_AR1.png"), width=1000, height=700)
itsadug::acf_resid(S_SSeek); dev.off()
png(file.path(DIR_SM, "acf_resid_S3_SSens_AR1.png"), width=1000, height=700)
itsadug::acf_resid(S_SSens); dev.off()
png(file.path(DIR_SM, "acf_resid_S4_SAvoid_AR1.png"), width=1000, height=700)
itsadug::acf_resid(S_SAvoid); dev.off()

# ---- Save S summaries (ADD THIS)
capture.output(summary(S_LReg),   file=file.path(DIR_S, "summary_S1_LReg_TBC.txt"))
capture.output(summary(S_SSeek),  file=file.path(DIR_S, "summary_S2_SSeek_TBC.txt"))
capture.output(summary(S_SSens),  file=file.path(DIR_S, "summary_S3_SSens_TBC.txt"))
capture.output(summary(S_SAvoid), file=file.path(DIR_S, "summary_S4_SAvoid_TBC.txt"))

# Save S models
saveRDS(S_LReg,   file=file.path(DIR_S, "model_S1_LReg_TBC.rds"))
saveRDS(S_SSeek,  file=file.path(DIR_S, "model_S2_SSeek_TBC.rds"))
saveRDS(S_SSens,  file=file.path(DIR_S, "model_S3_SSens_TBC.rds"))
saveRDS(S_SAvoid, file=file.path(DIR_S, "model_S4_SAvoid_TBC.rds"))

capture.output(gam.check(S_LReg),   file=file.path(DIR_SM, "gamcheck_S1_LReg_TBC.txt"))
capture.output(gam.check(S_SSeek),  file=file.path(DIR_SM, "gamcheck_S2_SSeek_TBC.txt"))
capture.output(gam.check(S_SSens),  file=file.path(DIR_SM, "gamcheck_S3_SSens_TBC.txt"))
capture.output(gam.check(S_SAvoid), file=file.path(DIR_SM, "gamcheck_S4_SAvoid_TBC.txt"))

capture.output(mgcv::concurvity(S_LReg,   full=TRUE), file=file.path(DIR_SM, "concurvity_S1_LReg_TBC_full.txt"))
capture.output(mgcv::concurvity(S_SSeek,  full=TRUE), file=file.path(DIR_SM, "concurvity_S2_SSeek_TBC_full.txt"))
capture.output(mgcv::concurvity(S_SSens,  full=TRUE), file=file.path(DIR_SM, "concurvity_S3_SSens_TBC_full.txt"))
capture.output(mgcv::concurvity(S_SAvoid, full=TRUE), file=file.path(DIR_SM, "concurvity_S4_SAvoid_TBC_full.txt"))

# ============================================================
# 13) FIGURES + CSV EXPORTS (Recommended A = EQCOND)
# ============================================================

# ---- Fig1: condition-wise predicted waveform from M1
FIG1_COND_CSV <- file.path(DIR_F, "Fig1_M1_condition_pred_pointwise.csv")
pred_ci_by_condition(m1_core, dat, tgrid, KEEP_CONDS, exclude_terms, ALPHA, FIG1_COND_CSV)

# ---- Build base per-condition ND list used for EQCOND predictions
nd_base_per_cond <- lapply(KEEP_CONDS, function(cn) make_nd_template(dat, tgrid, cn))
names(nd_base_per_cond) <- KEEP_CONDS

# ---- Fig2: M1 Dunn axes (LowTh, Active) EQCOND (pred pointwise + diff simul) + CSVs + PNGs
res_lowth <- eqcond_hi_lo_with_simul_diff(m1_core, "LowTh_z",
                                         nd_base_per_cond=nd_base_per_cond,
                                         wts=COND_WTS, exclude_terms=exclude_terms,
                                         nsim=NSIM, alpha=ALPHA)

res_active <- eqcond_hi_lo_with_simul_diff(m1_core, "Active_z",
                                          nd_base_per_cond=nd_base_per_cond,
                                          wts=COND_WTS, exclude_terms=exclude_terms,
                                          nsim=NSIM, alpha=ALPHA)

# Save Fig2 CSV (full)
write_csv(
  data.frame(
    Time_s=tgrid,
    Trait="LowTh_z",
    PPC_hi=res_lowth$fit_hi, PPC_lo=res_lowth$fit_lo,
    PPC_hi_lo=res_lowth$pw_hi_lo, PPC_hi_hi=res_lowth$pw_hi_hi,
    PPC_lo_lo=res_lowth$pw_lo_lo, PPC_lo_hi=res_lowth$pw_lo_hi,
    Diff=res_lowth$diff,
    Simul_lo=res_lowth$sim_diff_lo, Simul_hi=res_lowth$sim_diff_hi
  ),
  file.path(DIR_F, "Fig2_M1_EQCOND_LowTh_full.csv")
)

write_csv(
  data.frame(
    Time_s=tgrid,
    Trait="Active_z",
    PPC_hi=res_active$fit_hi, PPC_lo=res_active$fit_lo,
    PPC_hi_lo=res_active$pw_hi_lo, PPC_hi_hi=res_active$pw_hi_hi,
    PPC_lo_lo=res_active$pw_lo_lo, PPC_lo_hi=res_active$pw_lo_hi,
    Diff=res_active$diff,
    Simul_lo=res_active$sim_diff_lo, Simul_hi=res_active$sim_diff_hi
  ),
  file.path(DIR_F, "Fig2_M1_EQCOND_Active_full.csv")
)

# Save Fig2 PNGs
plot_pred_and_diff_eqcond(tgrid, res_lowth,
                          "M1 (EQCOND): Low threshold (±1 SD)",
                          file.path(DIR_F, "Fig2_M1_EQCOND_LowTh.png"))
plot_pred_and_diff_eqcond(tgrid, res_active,
                          "M1 (EQCOND): Active strategy (±1 SD)",
                          file.path(DIR_F, "Fig2_M1_EQCOND_Active.png"))

# ---- Fig3: AASP quadrant DIFF (High-Low) with simultaneous CI — EQCOND
res_S1 <- eqcond_hi_lo_with_simul_diff(
  model = S_LReg, trait_col = "LReg_z",
  nd_base_per_cond = nd_base_per_cond,
  wts = COND_WTS, exclude_terms = exclude_terms,
  nsim = NSIM, alpha = ALPHA
)
res_S2 <- eqcond_hi_lo_with_simul_diff(
  model = S_SSeek, trait_col = "SSeek_z",
  nd_base_per_cond = nd_base_per_cond,
  wts = COND_WTS, exclude_terms = exclude_terms,
  nsim = NSIM, alpha = ALPHA
)
res_S3 <- eqcond_hi_lo_with_simul_diff(
  model = S_SSens, trait_col = "SSens_z",
  nd_base_per_cond = nd_base_per_cond,
  wts = COND_WTS, exclude_terms = exclude_terms,
  nsim = NSIM, alpha = ALPHA
)
res_S4 <- eqcond_hi_lo_with_simul_diff(
  model = S_SAvoid, trait_col = "SAvoid_z",
  nd_base_per_cond = nd_base_per_cond,
  wts = COND_WTS, exclude_terms = exclude_terms,
  nsim = NSIM, alpha = ALPHA
)

FIG3_DIFF_CSV <- file.path(DIR_F, "Fig3_AASP_EQCOND_diff_simul_all.csv")
df_fig3 <- bind_rows(
  data.frame(Time_s=tgrid, Quadrant="S1: Low Registration (LReg)",   Diff=res_S1$diff, Simul_lo=res_S1$sim_diff_lo, Simul_hi=res_S1$sim_diff_hi),
  data.frame(Time_s=tgrid, Quadrant="S2: Sensation Seeking (SSeek)", Diff=res_S2$diff, Simul_lo=res_S2$sim_diff_lo, Simul_hi=res_S2$sim_diff_hi),
  data.frame(Time_s=tgrid, Quadrant="S3: Sensory Sensitivity (SSens)",Diff=res_S3$diff, Simul_lo=res_S3$sim_diff_lo, Simul_hi=res_S3$sim_diff_hi),
  data.frame(Time_s=tgrid, Quadrant="S4: Sensation Avoiding (SAvoid)",Diff=res_S4$diff, Simul_lo=res_S4$sim_diff_lo, Simul_hi=res_S4$sim_diff_hi)
)
write_csv(df_fig3, FIG3_DIFF_CSV)

# ---- Fig4: AASP quadrant PRED (High/Low) pointwise CI — EQCOND (one CSV)
FIG4_PRED_CSV <- file.path(DIR_F, "Fig4_AASP_EQCOND_pred_pointwise_all.csv")

df_fig4 <- bind_rows(
  export_quadrant_pred_eqcond(S_LReg,   "LReg_z",   "S1: Low Registration (LReg)",   dat, tgrid, KEEP_CONDS, COND_WTS, exclude_terms, ALPHA),
  export_quadrant_pred_eqcond(S_SSeek,  "SSeek_z",  "S2: Sensation Seeking (SSeek)", dat, tgrid, KEEP_CONDS, COND_WTS, exclude_terms, ALPHA),
  export_quadrant_pred_eqcond(S_SSens,  "SSens_z",  "S3: Sensory Sensitivity (SSens)",dat, tgrid, KEEP_CONDS, COND_WTS, exclude_terms, ALPHA),
  export_quadrant_pred_eqcond(S_SAvoid, "SAvoid_z", "S4: Sensation Avoiding (SAvoid)",dat, tgrid, KEEP_CONDS, COND_WTS, exclude_terms, ALPHA)
)
write_csv(df_fig4, FIG4_PRED_CSV)

# ---- (Optional) M2/M3 EQCOND trait plots/CSVs for supplementary robustness figures
# You can uncomment if you want them:
# res_m2_lowth <- eqcond_hi_lo_with_simul_diff(m2_core, "LowTh_z", nd_base_per_cond, COND_WTS, exclude_terms, NSIM, ALPHA)
# res_m2_active <- eqcond_hi_lo_with_simul_diff(m2_core, "Active_z", nd_base_per_cond, COND_WTS, exclude_terms, NSIM, ALPHA)
# write_csv(data.frame(Time_s=tgrid, PPC_hi=res_m2_lowth$fit_hi, PPC_lo=res_m2_lowth$fit_lo,
#                      PPC_hi_lo=res_m2_lowth$pw_hi_lo, PPC_hi_hi=res_m2_lowth$pw_hi_hi,
#                      PPC_lo_lo=res_m2_lowth$pw_lo_lo, PPC_lo_hi=res_m2_lowth$pw_lo_hi,
#                      Diff=res_m2_lowth$diff, Simul_lo=res_m2_lowth$sim_diff_lo, Simul_hi=res_m2_lowth$sim_diff_hi),
#           file.path(DIR_F, "FigS_M2_EQCOND_LowTh_full.csv"))
# write_csv(data.frame(Time_s=tgrid, PPC_hi=res_m2_active$fit_hi, PPC_lo=res_m2_active$fit_lo,
#                      PPC_hi_lo=res_m2_active$pw_hi_lo, PPC_hi_hi=res_m2_active$pw_hi_hi,
#                      PPC_lo_lo=res_m2_active$pw_lo_lo, PPC_lo_hi=res_m2_active$pw_lo_hi,
#                      Diff=res_m2_active$diff, Simul_lo=res_m2_active$sim_diff_lo, Simul_hi=res_m2_active$sim_diff_hi),
#           file.path(DIR_F, "FigS_M2_EQCOND_Active_full.csv"))

# ============================================================
# 14) Session info
# ============================================================
capture.output(sessionInfo(), file=file.path(OUT_DIR, "sessionInfo.txt"))
message("DONE. Outputs saved under: ", OUT_DIR)
message("Key CSVs:")
message("  Fig1: ", FIG1_COND_CSV)
message("  Fig2: ", file.path(DIR_F, "Fig2_M1_EQCOND_LowTh_full.csv"), " and ...Active...")
message("  Fig3: ", FIG3_DIFF_CSV)
message("  Fig4: ", FIG4_PRED_CSV)